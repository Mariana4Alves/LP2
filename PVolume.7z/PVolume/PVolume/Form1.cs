﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        Double raio;
        Double altura;
        double volume;

        public Form1()
        {
            InitializeComponent();
        }

        private void TxtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(TxtRaio.Text, out raio))
            {
                MessageBox.Show("Raio inválido!");
                TxtRaio.Focus();
            }
            else
            {
                if (raio<=0)
                {
                    MessageBox.Show("Raio deve ser maior que zero!");
                    TxtRaio.Focus();
                }
            }
        }

        private void TxtAltura_Validating(object sender, CancelEventArgs e)
        {
            if(!double.TryParse(TxtAltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                e.Cancel = true;
            }
            else
            {
                if(altura<=0)
                {
                    MessageBox.Show("Altura deve ser maior que zero!");
                    e.Cancel = true;
                }
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            TxtAltura.Clear();
            TxtRaio.Clear();
            TxtVolume.Clear();
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            TxtVolume.Text = volume.ToString("N2");
        }
    }
}
